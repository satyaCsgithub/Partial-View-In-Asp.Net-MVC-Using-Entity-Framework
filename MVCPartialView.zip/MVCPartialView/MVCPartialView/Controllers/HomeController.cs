﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCPartialView.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult ViewWithPartial()
        {
            return View();
        }

        public ActionResult SatyaAcademicYear()
        {
            using (SatyaprakashEntities dc = new SatyaprakashEntities())
            {
                var v = dc.AcademicYears.OrderByDescending(a => a.AcademicYear1).ToList();
                return PartialView("_AcademicYear", v);
            }
        }
        public ActionResult ViewWithPartialtwo()
        {
            return View();
        }
    }
}
